SimpleTheme is a contributed theme for DrupalGap mobile application development
Kit for Drupal websites.

  http://www.drupalgap.org

|==============|
| Installation |
|==============|

1. Download and extract the simpletheme folder into,

     www/app/themes/simpletheme

2. Open www/app/settings.js and replace the default theme with "simpletheme". 
   For example, If you are using "easystreet3" theme replace "easystreet3" 
   with "simpletheme"

3. Run your Mobile Application! and see the magic.

===================================

From here you'll have a great start to building a mobile application that
integrates with your Drupal website. Check out topics in the Getting
Started Guide to continue.

|=======================|
| Getting Started Guide |
|=======================|

http://www.drupalgap.org/get-started

|==================|
| More Information |
|==================|

http://www.drupalgap.org
http://api.drupalgap.org
