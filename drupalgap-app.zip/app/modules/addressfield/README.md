addressfield
============

The Address Field module for DrupalGap. For usage, install the following module
on your Drupal site, and follow it's README.txt file:

https://www.drupal.org/project/services_addressfield

