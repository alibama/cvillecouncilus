fivestar
========

The Fivestar module for DrupalGap.

Installation
============

Install this sandbox module on your Drupal site:

```
  https://drupal.org/sandbox/joshberry/1526726
```

Then enable the fivestar resources (retrieve, rate) under:

```
  admin/structure/services/list/drupalgap/resources
```

User Permissions
================

Make sure a user role(s) has permission to "rate content" on your Drupal site:

```
  admin/people/permissions
```

Other Resources
===============
 - https://drupal.org/project/fivestar
 - https://drupal.org/node/1308114

